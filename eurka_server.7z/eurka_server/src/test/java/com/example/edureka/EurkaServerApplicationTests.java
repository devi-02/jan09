package com.example.edureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurkaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
