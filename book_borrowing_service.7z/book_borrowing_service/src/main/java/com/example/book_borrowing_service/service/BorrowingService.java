package com.example.book_borrowing_service.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.book_borrowing_service.entity.Book;
import com.example.book_borrowing_service.entity.Borrowing;
import com.example.book_borrowing_service.entity.User;
import com.example.book_borrowing_service.repository.BorrowingRepository;

import feignclients.BookClient;
import feignclients.UserClient;

@Service
public class BorrowingService {
    @Autowired
    private BorrowingRepository borrowingRepository;

    @Autowired
    private UserClient userClient;

    @Autowired
    private BookClient bookClient;

    public Borrowing borrowBook(Long userId, Long bookId) {
     
        User user = userClient.getUserById(userId);
        Book book = bookClient.getBookById(bookId);

        if (!book.isAvailable()) {
            throw new RuntimeException("Book is not available for borrowing.");
        }

     
        Borrowing borrowing = new Borrowing(userId, bookId, LocalDate.now(), null);
        Borrowing savedBorrowing = borrowingRepository.save(borrowing);

   
        book.setAvailable(false);
        bookClient.updateBook(bookId, book);

        return savedBorrowing;
    }

    public Borrowing returnBook(Long borrowingId) {
        Borrowing borrowing = borrowingRepository.findById(borrowingId)
                .orElseThrow(() -> new RuntimeException("Borrowing record not found."));

        borrowing.setReturnDate(LocalDate.now());
        borrowingRepository.save(borrowing);

        Book book = bookClient.getBookById(borrowing.getBookId());
        book.setAvailable(true);
        bookClient.updateBook(book.getId(), book);

        return borrowing;
    }

    public List<Borrowing> getAllBorrowings() {
        return borrowingRepository.findAll();
    }
}