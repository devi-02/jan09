package feignclients;



import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.book_borrowing_service.entity.Book;

@FeignClient(name = "book-service", url = "http://localhost:9191/api/books")
public interface BookClient {
    @GetMapping("/{id}")
    Book getBookById(@PathVariable Long id);

    @PutMapping("/{id}")
    Book updateBook(@PathVariable Long id, @RequestBody Book book);
}